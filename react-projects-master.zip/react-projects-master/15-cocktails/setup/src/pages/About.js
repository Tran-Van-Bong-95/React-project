import React from 'react'

const About = () => {
  return (
    <div>
      <h2>about page</h2>
    </div>
  )
}

export default About

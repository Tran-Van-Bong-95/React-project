import React from 'react';

const Categories = () => {
  return <h2>categories component</h2>;
};

export default Categories;

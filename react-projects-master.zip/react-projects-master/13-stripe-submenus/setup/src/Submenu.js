import React, { useState, useRef, useEffect } from 'react'

const Submenu = () => {
  return <h2>submenu component</h2>
}

export default Submenu

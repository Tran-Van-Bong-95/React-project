import React, { useState } from 'react';
import data from './data';
function App() {
  
  
  return (
  <h2>lorem ipsum project setup</h2>
    )
}

export default App;
